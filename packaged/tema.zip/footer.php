   <?php 
   //Wia this I will add scripts to the WP
   wp_footer(); ?>
   
   </body>
</html>